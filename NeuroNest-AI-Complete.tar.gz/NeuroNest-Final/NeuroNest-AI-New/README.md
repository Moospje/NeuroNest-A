# NeuroNest-AI-New

Este directorio se utiliza para la reestructuración del proyecto NeuroNest-AI.

## Propósito

Este directorio contiene archivos temporales y de configuración para la migración del proyecto desde la estructura anterior basada en Express.js a la nueva estructura basada en FastAPI.

## Contenido

- Archivos de configuración para la migración
- Scripts de conversión de datos
- Documentación del proceso de migración